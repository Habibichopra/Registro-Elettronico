<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Registro Elettronico - Dashboard</title>
    </head>
    <body>
        <!--
            Orario lezioni
            Voti
            Assenze e giustificazioni
            Comunicazioni
            Registro di classe (argomenti lezioni, 
                compiti/veriche assegnate, assenze, note [eventuali note disciplinari])

            Sezione compiti e materiali
                Visualizzazione compiti (Studenti)
                    Filtri per materia o data.
            
            Profilo personale
                Per tutti i ruoli:
                    Modifica dati personali (non sensibili).
                    Cambio password.
        -->
    </body>
</html>