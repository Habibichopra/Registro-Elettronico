<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Registro Elettronico - Dashboard Docente</title>
    </head>
    <body>
        <!--
            classi assegnate
            gestione classe (presenze, ritardi, assegnazione eventuali note allo studente)
            registro voti (inserimento con eventuali informazioni aggiuntive)
            compiti assegnati
            comunicazioni da inviare


            Registro presenze (Docenti) -> pagina alternativa
                Pagina per segnare presenza/assenza
                    Selezione classe.
                    Lista studenti (selezione studente = assente, ritardo/entrate/uscite (con orario), giustificato)
                Storico presenze
                    Filtri per data, studente, classe.

            Gestione voti (Docenti)
                Inserimento voti
                    Selezione studente, materia, tipologia verifica (scritto/orale/pratico), voto, data.
                Visualizzazione voti
                    Filtri per classe, studente, materia.
            
            Sezione compiti
                Assegnazione compiti (Docenti)
                    Materia.
                    Descrizione.

            Pagina delle comunicazioni
            Creazioni comunicazioni?
                (esempio: entrata posticipata xx/yy/zz 09:00)
                Comunicazioni scuola → studenti
                Comunicazioni docenti → classe
                Lettura notifiche

            Profilo personale
                Per tutti i ruoli:
                    Modifica dati personali (non sensibili).
                    Cambio password.
                    Foto profilo
        -->
    </body>
</html>