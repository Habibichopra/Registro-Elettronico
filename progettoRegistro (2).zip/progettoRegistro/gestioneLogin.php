<?php
    if (!isset($_SESSION))
        session_start();
    $fileName = "users.txt";
    //se l'utente è gia autenticato --> header(location...)
    if (isset($_SESSION["username"]) == file_get_contents($fileName))
    {
        header("location:index.php");
        exit();
    }
    //ci sono i parametri corretti?
    if(isset($_GET["username"]) || !isset($_GET["password"]))
    {
        
        //no --> header(location:login.php) + errore "parametri mancanti"
        redirect("index.php", "user o pass non passati");
    }
        
    require("costanti.php");
    //user e pass sono corretti?
    if ($_GET["username"] != $UserCorr || $_GET["password"] != $passCorr)
    {
        //no --> header(location:login.php) + errore "user e pass errati"
        
        redirect("index.php", "user o pass sbagliati");
    }
        

    //salvare nella sessione e nel file username per identificare l'utente come autenticato
    $_SESSION["username"] == $_GET["username"];
    $handle = fopen($fileName, 'a');

    if ($handle)
    {
        fwrite($handle, $_GET["username"]);
        fwrite($handle, " ");
        fwrite($handle, $_GET["password"]);
        fwrite($handle, "\n");
        fclose($handle);
    } /*--> sostituire x query di inserimento dati nelle tabelle*/
    redirect("index.php"); /*--> pagina successiva (fare controllo del tipo di utente che si è autenticato; dal database)*/ 


    function redirect($url, $mex)
    {
        if ($mex == null)
        {
            header("location:".$url)
        }
        else 
        {
            $mess = urlencode("user o pass sbagliati");
            header("location:l".$url."?messaggio=".$mess);
        }
       
        exit(); 
    }
?>