<?php
    if (!isset($_SESSION))
    {
        session_start();
    }
    $_SESSION["username"] = '';
    $_SESSION["password"] = '';
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Registro Elettronico - Login</title>
    </head>
    <body>
        <!--
            login 
                con username + password (HASH)
                (ruolo assegnato automaticamente, il database lo deve riconoscere)
            UTILIZZO SESSIONI!
        -->

        <?php

        ?>
        <form method="GET"action="gestioneLogin.php">
            username:<input type="text" name="username"> <br>
            password:<input type="pass" name="password"> <br>
            <button>login1</button> 
        </form>
    </body>
</html>