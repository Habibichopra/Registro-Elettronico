<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Registro Elettronico - Dashboard ADMIN</title>
    </head>
    <body>
        <!-- 
            gestione utenti (modifica informazioni docenti/studenti [modifica con query database MySQL])
            Gestione studenti e docenti (Admin) -> pagina alternativa
            Lista utenti
                Elenco studenti.
                Elenco docenti.
            Aggiunta/modifica/cancellazione utenti
                Modulo per creare studenti/docenti.
                Collegamento studente → classe.
                Collegamento docente → materie/classi.

            Profilo personale/anagrafico?
                Per tutti i ruoli:
                    Modifica dati personali (non sensibili).
                    Cambio password.
                    Foto profilo
        -->
    </body>
</html>