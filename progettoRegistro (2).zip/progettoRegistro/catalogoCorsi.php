<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Registro Elettronico - catalogo corsi</title>
    </head>
    <body>
        <!--
            Catalogo corsi (visibile a studenti e genitori)
                Elenco dei corsi disponibili.
                Descrizione del corso.               
                Docente responsabile.                
                Numero massimo di partecipanti                
                Periodo di svolgimento.               
                Eventuali prerequisiti.
                + BUTTON "ISCRIVITI"

            Dettaglio corso (CORSO SELEZIONATO) -> pagina alternativa?
                Informazioni complete.
                Programma.
                Date lezioni.
                Materiali.
                Lista iscritti (solo per docenti e amministratori).
                Stato iscrizione dello studente.
                Azioni:
                    Iscriviti / Ritira iscrizione
                    Per docenti: modifica info corso

            Gestione iscrizioni (Admin/Docente)
                Elenco iscrizioni per corso.
                Lista studenti iscritti + stato (confermato/in lista d’attesa).
                Possibilità di rimuovere iscritti.
                Gestione limiti di partecipanti.

            Pannello studente → I miei corsi
                Corsi a cui è iscritto.
                Stato (iscritto, in attesa, respinto).
                Calendario lezioni.

            Creazione e modifica corsi (Admin/Docenti)
                Nome corso
                Docente assegnato.                
                Numero massimo partecipanti.                
                Periodo.                
                Aule.  
                Descrizione.
                Caricamento materiali.

            Pagine per la gestione richieste di iscrizione
            (non obbligatorie, ma utili se vuoi fare più realistico)
            SOLO Per admin:
                Lista iscrizioni in attesa.
                Possibilità di approvarle/rifiutarle.
        -->
    </body>
</html>